# Package initializer for slowql.effects
__all__ = ["animations"]   # list modules you want exported
